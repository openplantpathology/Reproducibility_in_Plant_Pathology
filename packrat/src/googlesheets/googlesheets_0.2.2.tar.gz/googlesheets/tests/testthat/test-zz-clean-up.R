activate_test_token()
gs_grepdel(TEST, verbose = FALSE)
gs_deauth(verbose = FALSE)
