library(XDynDocs)
dynDoc("verySimple.xml", "HTML", force = TRUE)
gc()

