library(testthat)
library(humaniformat)

test_check("humaniformat")
