library("testthat")
library("bib2df")
test_check("bib2df")
